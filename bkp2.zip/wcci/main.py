#!/usr/bin/python
# -*- coding: <encoding name> -*-

import csv

import keras
from keras.datasets import mnist

import dnn_optimization_problem as dnn_problem
from platypus import *

print(sys.version)


def write_csv(name_file, rows):
    """
    Salvar em arquivos

    :param name_file:
    :param rows:
    :return:
    """
    file_csv = csv.writer(open(name_file, "a"))
    file_csv.writerow(rows)


if __name__ == '__main__':

    # Base Cifar10
    print("Carregando Base")
    # the data, split between train and test sets
    (x_train, y_train), (x_test, y_test) = mnist.load_data()

    print("Configuração da Base")
    # input image dimensions
    img_rows, img_cols = 28, 28
    # output dimension
    num_classes = 10

    # Shape (num_samples,3,32,32)
    # convert class vectors to binary class matrices
    y_train = keras.utils.to_categorical(y_train, num_classes)
    y_test = keras.utils.to_categorical(y_test, num_classes)

    print("Configurando Problem")

    problem2 = dnn_problem.OptimizationProblem(name='Problem', base_x=x_train, base_y=y_train, len_categories=num_classes)
    # define o algoritmo de otimização
    optimizer = NSGAII(problem=problem2, population_size=10)
    # define quantidade de gerações
    num_generations = 50
    # Modelo proposto
    # inicia o algoritmo
    start = time.time()
    int1 = Integer(0, 3)
    for gen in range(num_generations):
        # executa por uma geração
        problem2.set_gent(gen)
        print(">>>>>>>>>>>>>Generation {}<<<<<<<<<<<<<<<\n".format(gen))
        optimizer.run(1)
        print(">>>>>>>>>>>>>RESULTS<<<<<<<<<<<<<<<\n")
        val = optimizer.result[0].objectives
        var = optimizer.result[0].variables

        print(">>>>>>>>>>>>>Save datas<<<<<<<<<<<<<<<\n")
        #The output shows on each line the objectives for a Pareto optimal solution:
        print("Pareto_objectives")
        pareto = []
        for i in optimizer.result:
            pareto.append(i.objectives)
        write_csv('pareto_objective_{}.csv'.format(gen), pareto)

        print("Pareto_variables")
        pareto = []
        for results in optimizer.result:
            print(results.variables)
            pareto_tmp = []
            for result in results.variables:
                print(result)
                pareto_tmp.append(int1.decode(result))
            pareto.append(pareto_tmp)
        print(pareto)
        write_csv('pareto_variables_{}.csv'.format(gen), pareto)

        print("Best_of_arch")
        var_int = []
        for i in var:
            var_int.append(int1.decode(i))
        write_csv('best_of_arch_{}.csv'.format(gen), var_int)

        print("Best_of_objetives")
        # acuracia = -val[0]
        # fmeasure = -val[1]
        row = -val[0], -val[1]
        write_csv('best_of_objetives_{}.csv'.format(gen), row)

    end = time.time()
    tmp = round((end - start), 2)
    print("Tempo de execução {}".format(tmp))

    arq = open('tempo_exec.txt', 'a')
    result = ("Tempo" + str(tmp))
    arq.write(result)
    arq.write("\n")
    arq.close()
