#!/usr/bin/python
# -*- coding: <encoding name> -*-

import csv

import matplotlib.pyplot as plt
from keras import backend as bcknd
from keras.callbacks import EarlyStopping
from keras.layers import *
from keras.models import *
from keras.optimizers import SGD
from sklearn.metrics import (accuracy_score, classification_report,
                             precision_recall_fscore_support)

from platypus import *

print(sys.version)


class OptimizationProblem(Problem):
    """

    """
    def __init__(self, name, base_x, base_y, len_categories):
        encoding = [Integer(0, 3), Integer(0, 3),
                    # 2	        3	    4		      5
                    Integer(0, 3), Integer(0, 3), Integer(0, 3), Integer(0, 3),
                    # 6
                    Integer(0, 3)]

        self.variables = len(encoding)

        objectives = 2
        super(OptimizationProblem, self).__init__(self.variables, objectives)
        self.types[:] = encoding
        self.class_name = name
        self.base_x = base_x
        self.base_y = base_y
        self.gen = None
        self.batch_size = 200  # de quanto em quanto vai caminhar
        self.epochs = 50  # repeticoes
        self.solutions = {}  # dicionario de solucoes
        self.id = 0
        self.len_categories = len_categories

    @staticmethod
    def __defaultt_dnn(input_shape):
        """

        :param input_shape:
        :return:
        """
        model = Sequential()
        model.add(Conv2D(filters=5, kernel_size=4, padding="same", input_shape=input_shape))
        model.add(Conv2D(filters=5, kernel_size=4, padding="same"))
        model.add(MaxPooling2D(pool_size=[2, 2], strides=2))
        model.add(Conv2D(filters=5, kernel_size=4, padding="same"))
        model.add(Flatten())
        model.add(Dense(units=5, activation='softmax'))
        return model

    def __modifiedd_dnn(self, solution, input_shape):
        """

        :param solution:
        :param input_shape:
        :return:
        """
        md = Sequential()
        md.add(Conv2D(filters=5, kernel_size=4, padding="same", input_shape=input_shape))

        for i in range(0, self.variables, 1):
            if solution.variables[i] != 0:
                if solution.variables[i] == 1:
                    md.add(MaxPooling2D(pool_size=[2, 2], strides=2))
                elif solution.variables[i] == 2:
                    md.add(Conv2D(filters=5, kernel_size=4, padding="same"))
                elif solution.variables[i] == 3:
                    md.add(Dense(units=self.len_categories, activation='softmax'))
        md.add(Flatten())
        md.add(Dense(units=self.len_categories, activation='softmax'))
        return md

    def get_solucao_final(self, info):
        """

        :param info:
        :return:
        """
        return self.solutions.get(info)
    def set_gent(self, gen):
        self.gen = gen

    def evaluate(self, solution):
        """

        :param solution:
        :return:
        """

        print("Treino-Teste")
        x_train, y_train, x_test, y_test, _, _ = self.__split_dataset_random(self.base_x, self.base_y, 0.2, 0.2)

        print("Criando o modelo")
        model = self.__modifiedd_dnn(solution=solution, input_shape=x_train.shape[1:])
        print(model.summary())

        print("Compilando")
        learning_rate = 0.1
        decay_rate = learning_rate / self.epochs
        momentum = 0.8
        sgd = SGD(lr=learning_rate, momentum=momentum, decay=decay_rate, nesterov=False)
        model.compile(loss='binary_crossentropy', optimizer=sgd, metrics=['accuracy'])

        print("Iniciando treinamento")
        early_stopping = EarlyStopping(monitor='val_acc', min_delta=0.001, patience=10, verbose=1, mode='auto')
        print(x_train.shape)
        history = model.fit(x_train, y_train, batch_size=self.batch_size,
                            epochs=self.epochs,
                            callbacks=[early_stopping],
                            validation_split=0.33,
                            shuffle=True,
                            verbose=2)

        # Salva o resultado de treinamento
        plt.clf()
        plt.plot(history.history['acc'])
        plt.plot(history.history['val_acc'])
        plt.title('model accuracy')
        plt.ylabel('accuracy')
        plt.xlabel('epoch')
        plt.legend(['train', 'validation'], loc='upper left')
        # plt.savefig(str(self.id)+'_accuracy')
        plt.clf()
        # train_acc = history.history['acc'][-1]
        val_acc = history.history['val_acc'][-1]

        # metrics################################################################
        print('\n acc', val_acc)
        predictions = model.predict(x_test, batch_size=self.batch_size)
        print(classification_report(y_test.argmax(axis=1),
                                    predictions.argmax(axis=1)))
        report_lr = precision_recall_fscore_support(y_test.argmax(axis=1),
                                                    predictions.argmax(axis=1),
                                                    average='macro')

        print("\nprecision = %0.2f, recall = %0.2f, F1 = %0.2f, accuracy = %0.2f\n" %
              (report_lr[0], report_lr[1], report_lr[2], accuracy_score(y_test.argmax(axis=1),
                                                                        predictions.argmax(axis=1))))

        if bcknd.backend() == 'tensorflow':
            bcknd.clear_session()

        self.id += 1

        solution.objectives[:] = [-val_acc, - report_lr[2]]

        variaveis = []
        print(solution.objectives)
        for i in solution.variables:
            variaveis.append(i)
        self.solutions.update({solution.objectives: variaveis})

        print(solution.constraint_violation)

        # Salvar dados
        print("Salvando dados...")
        self.__write_csv('best__arch_{}.csv'.format(self.gen), solution.variables)
        row = solution.objectives
        self.__write_csv('best__objetives_{}.csv'.format(self.gen), row)

    @staticmethod
    def __split_dataset_random(b_x, b_y, p_train, p_val):
        """
        divide base aleatoriamente em treinamento, teste e validação

        :param b_x:
        :param b_y:
        :param p_train:
        :param p_val:
        :return:
        """
        total_samples = b_x.shape[0]
        train_size = int(total_samples * p_train)
        valid_size = int(total_samples * p_val)
        test_size = total_samples - train_size - valid_size

        print('train set:', train_size, ' images')
        print('validation set:', valid_size, ' images')
        print('test set:', test_size, ' images')

        x_tr = np.zeros((train_size, b_x[0].shape[0], b_x[0].shape[1], b_x[0].shape[2]))
        y_tr = np.zeros((train_size, b_y[0].shape[0]))

        x_val = np.zeros((valid_size, b_x[0].shape[0], b_x[0].shape[1], b_x[0].shape[2]))
        y_val = np.zeros((valid_size, b_y[0].shape[0]))

        x_te = np.zeros((test_size, b_x[0].shape[0], b_x[0].shape[1], b_x[0].shape[2]))
        y_te = np.zeros((test_size, b_y[0].shape[0]))

        from random import shuffle
        index = list(range(total_samples))
        shuffle(index)

        for i in range(total_samples):
            if i < train_size:
                x_tr[i] = b_x[index[i]]
                y_tr[i] = b_y[index[i]]
            elif i < (train_size + valid_size):
                x_val[i - train_size] = b_x[index[i]]
                y_val[i - train_size] = b_y[index[i]]
            else:
                x_te[i - train_size - valid_size] = b_x[index[i]]
                y_te[i - train_size - valid_size] = b_y[index[i]]

        return x_tr, y_tr, x_te, y_te, x_val, y_val

    @staticmethod
    def __write_csv(name_file, rows):
        """
        Salvar em arquivos

        :param name_file:
        :param rows:
        :return:
        """
        file_csv = csv.writer(open(name_file, "a"))
        file_csv.writerow(rows)
